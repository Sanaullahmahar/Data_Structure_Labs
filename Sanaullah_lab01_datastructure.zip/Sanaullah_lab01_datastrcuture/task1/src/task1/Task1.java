package task1;
public class Task1 {

    public static void main(String[] args) {
       int arr[] = {5,15,25,35,45,55};
       for(int i=0; i<arr.length; i++){
           System.out.print( arr[i] + " ");
       }
        System.out.println();
       for(int i=0; i<arr.length; i++){
           System.out.println("Element at index " + i + ": " + arr[i]);
       }
    }
    
}
