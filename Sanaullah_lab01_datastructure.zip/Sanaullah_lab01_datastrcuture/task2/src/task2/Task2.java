package task2;
public class Task2 {
    public static void main(String[] args) {
        //Exercise 01
      System.out.println("Exercise 01");
      int arr [] = new int[6];
      arr[0]=12;
      arr[1]=24;    arr[2]=36;
      arr[3]=48;    arr[4]=60;
      int n_element = 6;     
      for(int i = arr.length-1; i>0; i--){arr[i]=arr[i-1]; }
      arr[0]=n_element;      
      for(int i=0; i<arr.length; i++){
          System.out.print(arr[i]+" "); }
      // Exercise 02
        System.out.println();
        System.out.println("Exercise 02");
      int[] array = new int[6];
        array[0] = 100;
        array[1]= 200;     array[2]= 300;
        array[3] = 400;     array[4]= 500;
         int n_element2=250;
         int position=2;
         for(int i=array.length-1; i>position; i--){
         array[i]=array[i-1];
         }
         array[position]=n_element2;
         for(int i =0; i<array.length; i++){
             System.out.println(array[i]); }
         // Exercise 02
        System.out.println("Exercise 03");
     int array3[]= new int [6];
     array3[0]=3;     array3[1]=6;
     array3[2]=9;     array3[3]=12;
     array3[4]=15;
     int n_element3=18;
     array3[array3.length-1] =n_element3;
     for(int i=0;i <array3.length; i++){
        System.out.println(array3[i]+""); }}}
