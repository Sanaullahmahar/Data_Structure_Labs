/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task7;
import java.util.Scanner;
import java.util.Arrays;
public class Task7 {
    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
        System.out.println("Input two strings:");
       String str1 = scan.nextLine();
       String str2 = scan.nextLine();
       char arr1[] =str1.toCharArray();
       char arr2[] =str2.toCharArray();
       Arrays.sort(arr1);
        Arrays.sort(arr2);
        boolean found = true;
        for(int i=0; i<arr1.length; i++){
        if(arr1[i]!=arr2[i]){
        found=false;
        break;
        }
        }
        if(found){
            System.out.println("String is anagram");
        }else{System.out.println("String is not anagram");}
    }
    
}
