/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task5;

import java.util.Scanner;

public class Task5 {

    public static void main(String[] args) {
      int arr[] = new int[5];
        System.out.println("Input array elements: ");
       Scanner scan = new Scanner(System.in);
       
       for(int i=0; i<arr.length; i++){
       int input=scan.nextInt();
       arr[i]=input;
       }
        System.out.println("Array after reversing: ");
       int rev_arr[] = new int[arr.length];
       for(int i=0; i<arr.length; i++){
       rev_arr[i]=arr[arr.length-i-1];
       }
       for(int i=0; i<arr.length; i++){
           System.out.println(rev_arr[i]);
       }
       
    }
    
}
