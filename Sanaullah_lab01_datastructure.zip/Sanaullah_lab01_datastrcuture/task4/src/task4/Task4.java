/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task4;
public class Task4 {
    public static void main(String[] args) {
        // Exercise 01 task  04
     int arr1[] = {13,26,39,52,65};
       int index = 4;
        System.out.println("Element at index 4: "+ arr1[index]);
       // Exercise 02 task  04
          int arr2[]= {2,4,6,8,10};
      int search = 8;
      boolean found=false;
      for(int i=0; i<arr2.length; i++){
      if(arr2[i]==search){
          System.out.println("Element "+ search +" is at index: "+i);
          found =true;
          break;   }}
      if(found==false){
          System.out.println("Element not found");}
      // Exercise 03 task  04
       int arr3[] = {11,22,33,44,55};
       int left =0; 
       int right = arr3.length-1;
       int mid;
       int search2=33;
       boolean found2 = false;
       while (left<=right){
       mid = left+right/2;
       if(arr3[mid] == search2){
           System.out.println("Element " + search2 + " found at index "+ mid);
           found2 = true;
           break;}
       if(arr3[mid]<search2){
       left = mid +1;    
       }else {
       right = mid-1;}}
       if(found2 == false){
           System.out.println("Element not found.");       }  }}
