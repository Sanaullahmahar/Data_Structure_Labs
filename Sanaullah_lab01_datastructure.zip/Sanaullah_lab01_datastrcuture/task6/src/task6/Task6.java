/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task6;

import java.util.Scanner;

public class Task6 {
    public static void main(String[] args) {
    System.out.println("Input any string: ");
    Scanner scan = new Scanner(System.in);
    String input = scan.nextLine();
    char arr[]=input.toCharArray();
    boolean found = true;
    for(int i=0; i<arr.length/2; i++){
    if(arr[i] != arr[arr.length-1-i]){
    found = false;
    break;
    }
    }
    if(found){
        System.out.println("String is palindrome");
    }else{
        System.out.println("String is not palindrome");
    }
    }
    
}
