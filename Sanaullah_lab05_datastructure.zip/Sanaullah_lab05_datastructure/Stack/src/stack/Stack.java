package stack;
public class Stack {
    public class Node{
    int data;
    Node next;
    Node(int data){
    this.data = data;
    this.next = null;
    }
    }
    private Node top;
    Stack(){
    this.top = null;
    }
    void push(int data){
        Node newNode = new Node(data);
    if(top == null){
    top = newNode;
    }else{
    newNode.next = top;
    top = newNode;
    }
    }
    int peek(){
        return top.data;
    }
    int pop(){
        int temp = top.data;
        top = top.next;
       return temp;
    }
    boolean isEmpty(){
    return top == null;
    }
    void traverse(){
        if(top == null){
            System.out.println("Stack  is empty!");
            return;
        }
        Node current = top;
    while(current!=null){
          System.out.println(current.data + " ");
            current= current.next;
    }
    }
    public static void main(String[] args) {
       Stack st = new Stack();
       st.push(30);
       st.push(20);
       st.push(10);
     //st.traverse();
       System.out.println(st.pop());
      // st.traverse();
       System.out.println(st.peek());
       System.out.println(st.isEmpty());
        System.out.println("----------Final Stack------------");
        st.traverse();
    }
    
}
