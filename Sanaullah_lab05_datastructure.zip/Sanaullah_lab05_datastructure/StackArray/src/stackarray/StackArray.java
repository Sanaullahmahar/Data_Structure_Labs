
package stackarray;
import java.util.Scanner;
public class StackArray {
    int top ;
    int arr[] ;
  int size;
    public StackArray(int size) {
        this.size=size;
        this.top = -1;
        arr = new int[this.size];
    }
    boolean isFull(){
    return top == size-1;
    }
    
    void push(int data){
        if(isFull()){
            System.out.println("Stack overflow!");
            
        }else{
      top++;
    arr[top]=data;}
    }
    void pop(){
        if(top<0){
            System.out.println("Stack underflow!");
            return;
        }
        System.out.println(arr[top]);
        top--;
    }
    int peek(){
       return arr[top]; 
    }
     boolean isEmpty(){
    return top == -1;
    }
     void traverse(){
     for(int i=top; i>=0; i--){
         System.out.println(arr[i]+" ");
     }
     }
    public static void main(String[] args) {
        System.out.print("Enter stack size: ");
        Scanner input = new Scanner(System.in);
        int index=input.nextInt();
                
      StackArray st = new StackArray(index);
      st.push(3);
      st.push(4);
      st.push(6);
      st.push(10);
      st.push(7);
      st.traverse();
      st.push(2);
      st.push(20);
      st.pop();
  //    st.pop();
    //  st.pop();
      //st.pop();
    //  st.pop();
     // st.pop();
        System.out.println("----------Final Stack--------------");
        st.traverse();
      
     
      

      
    }
    
}
