
package doublylinkedlist;
public class DoublYLinkedList {
    public class Node{
        int data;
        Node next;
        Node prev;
        Node (int data){
        this.data = data;
        this.next = null;
        this.prev = null;
        }
    }
    Node head;
    Node tail;
    DoublYLinkedList(){
    this.head = null;
    this.tail = null;
            
    }
    
    void insertAtstart(int data){
    Node newNode  = new Node (data);
    if(head == null){
    head = newNode;
    tail = newNode;
    }else{
    newNode.next = head;
    head = newNode;
    }
    }
    void displayAll(){
    Node current = head;
    while(current!=null){
        System.out.print(current.data + "->");
        current = current.next;
    }
        System.out.println("null");
    }
    void insertAtend(int data){
    Node newNode  = new Node(data);
    if(head == null){
    head = newNode;
    }else{
    newNode.prev = tail;    
    tail.next= newNode;
    tail = newNode;
    }
    }
    
    void insertAtposition(int data, int pos){
    Node newNode = new Node(data);
    Node temp = head;
    for(int i=0; i<pos-1; i++){
        temp = temp.next;
    }
    newNode.next = temp.next;
    newNode.prev = temp;
    if(temp.next != null){
        temp.next.prev = newNode;
    }else{
        tail = newNode;
    }
    temp.next = newNode;
}

    void deleteAtstart(){
       
    if(head == null){
        System.out.println("List is empty!");
    }else{
        head = head.next;
        head.prev=null;
        
    }
    }
    void deleteAtlast(){

    if(tail != null){
        if(tail.prev != null){
            tail.prev.next = null;
            tail = tail.prev;
        }else{
            head = null;
            tail=null;}
    }
    }
  void deleteByval(int val){
    Node current = head;
    while(current!=null){
        if(current.data == val){
            if(current == head){
                head = current.next;
                if(head!= null){
                    head.prev = null;
                }else{
                    tail = null;
                }
            }else{
                current.prev.next = current.next;
                if(current == tail){
                    tail = current.prev;
                }else{
                    current.next.prev = current.prev; 
                }
            }
            return;
        }else{
            current = current.next; 
        }
    }
}
  void search(int val){
  Node temp = head;
  int count = 0;
  boolean flag = false;
  while(temp!=null){
  if(temp.data == val){
     flag = true;
      System.out.println("Value found at index: " + count);
      break;
  }
   count++;
  temp = temp.next;
  }
      if(flag == false){
          System.out.println("Value not found!");
      }
  }
  void countNode(){
  Node temp = head;
  int count = 0;
  while(temp!=null){
  count++;
  temp = temp.next;
  }
      System.out.println("Number of nodes are: " + count);
  }
  void reverseList(){
  Node temp = tail;
  while(temp != null){
      System.out.print(temp.data + "->");
      temp = temp.prev;
  }
  }

    public static void main(String[] args) {
       DoublYLinkedList list = new DoublYLinkedList();
        System.out.println("Insert at start!");
       list.insertAtstart(1);
       list.insertAtstart(2);
       list.displayAll();
        System.out.println("Insert at end!");
       list.insertAtend(4);
       list.insertAtend(5);
       list.displayAll();
        System.out.println("Insert at position!");
       list.insertAtposition(3, 2);
       //list.insertAtend(7);
       list.displayAll();
        System.out.println("Delete at end!");
       list.deleteAtlast();
        System.out.println("Delete at start!");
       list.deleteAtstart();
       list.displayAll();
       list.deleteAtlast();
       list.displayAll();
        System.out.println("Delete by value!");
       list.deleteByval(4);
       list.displayAll();
        System.out.println("Searching!");
       list.search(1);
       System.out.println("Count nodes!");
       list.countNode();
          System.out.println("Reversing list!");
       list.reverseList();
               
    }
    
}
