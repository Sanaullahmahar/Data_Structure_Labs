/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package char_diffrence;

public class Char_diffrence {
   public char finddifference(String t,String s){
   char[] chars=s.toCharArray();
  
   boolean flag=true;
   char[] chart=t.toCharArray();
   for(int i=0;i<chars.length;i++){
        char letter=chars[i];
   for(int j=0;j<chart.length;j++){
   if(chars[i]==chart[j]){
       flag=false;
      break;
   }
   }
   if(flag==true){
      letter=chars[i];
      return letter;
   }
   flag=true;
   }
return 'N';
}
    public static void main(String[] args) {
       Char_diffrence c=new Char_diffrence ();
        System.out.println(c.finddifference("abcd", "abcde"));
    

    
}}
