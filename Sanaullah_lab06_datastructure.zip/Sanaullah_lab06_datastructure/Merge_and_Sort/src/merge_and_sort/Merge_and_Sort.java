/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package merge_and_sort;


public class Merge_and_Sort {

    public void Solution(int n, int m, int nums1[], int nums2[]){ 
        int arr3[] = new int [n+m];
         for(int i=0; i<m; i++){
            arr3[i] = nums1[i];
        }
        int k =0;
        for(int j=m; j<m+n; j++){
            arr3[j]=nums2[k];
            k++;
             
            
        }
        
        for(int i=0; i<arr3.length-1; i++){
            for(int j=0; j<arr3.length-1; j++){
                if(arr3[j] > arr3[j+1]){
                    int temp = arr3[j];
                    arr3[j]=arr3[j+1];
                    arr3[j+1]=temp;
                }
            }
        }
        for(int i=0; i<arr3.length; i++){
            System.out.print(arr3[i] + " ");
        }
    }
    public static void main(String[] args) {
        int nums1 [] = {1,2,3,0,0,0};
        int nums2 [] = {2,5,6};
        int n = 3;
        int m = 3;
        Merge_and_Sort ms = new Merge_and_Sort();
        ms.Solution(n, m, nums1, nums2);
        int nums3[] = {1};
        int nums4[] = {};
        int n3=0;
        int m4=1;
        System.out.println();
        ms.Solution(n3, m4, nums3, nums4);
        int nums6[] = {1};
        int nums5[] = {};
        int m5=0;
        int n6=1;
        System.out.println();
        ms.Solution(n6, m5, nums5, nums6);
    }
    
}
