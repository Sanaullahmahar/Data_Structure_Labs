package bubble_sort;

public class Bubble_Sort {
    public void bubbleSort(int arr[]){
        int count1 = 0;
        int count2 = 0;
        System.out.println("\nBefore Sorting: ");
        for(int i=0; i<arr.length; i++){
            System.out.print(arr[i]+ " ");
        }
        
         for(int i=0; i<arr.length-1; i++){
            for(int j=0; j<arr.length-1; j++){
                if(arr[j] > arr[j+1]){
                    int temp = arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                }
                count1++;
            }
            count2++;
        }
         System.out.println("\nInner loop: " + count1+ " \nOuter loop: " +count2);
         
         System.out.println("After Sorting: ");
        for(int i=0; i<arr.length; i++){
            System.out.print(arr[i]+ " ");
        }
    }
    
    void early_stop_sorting(int arr[]){
        boolean flag = false;
        int outer =0;
        int inner =0; 
          System.out.println("\nBefore Sorting: ");
        for(int i=0; i<arr.length; i++){
            System.out.print(arr[i]+ " ");
        }
        for(int i=0; i<arr.length-1; i++){
            outer++;
            for(int j=0; j<arr.length-1; j++){
                inner++;
                if(arr[j] > arr[j+1]){
                    int temp = arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                    flag = true;
                    
                }
                if(flag == false){
                break;
            }
                
            }
           
            flag = false;
        }
        
         System.out.println("\nAfter Sorting: ");
        for(int i=0; i<arr.length; i++){
            System.out.print(arr[i]+ " ");
        }    
        System.out.println("\nouter loop: " + outer+ "\ninner loop: " +inner);
            
    }
    void sort_words(String arr[]){
          System.out.println("\nBefore Sorting: ");
        for(int i=0; i<arr.length; i++){
            System.out.print(arr[i]+ " ");
        }
         for(int i=0; i<arr.length-1; i++){
            for(int j=0; j<arr.length-1; j++){
                if(arr[j].length() > arr[j+1].length()){
                    String temp = arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                }
            }
        }
         
          System.out.println("\nAfter Sorting: ");
        for(int i=0; i<arr.length; i++){
            System.out.print(arr[i]+ " ");
        } 
    }
    public void reducestepssorting(int arr[]){
       System.out.print("Before Sorting: ");
        for (int i=0;i<arr.length;i++){
       System.out.print(arr[i]+" ");
   }
       int count=arr.length-1;
       int outer=0;
       int inner=0;
      for(int i=0;i<arr.length-1;i++){
           outer++;
      for (int j=0;j<count;j++){
         inner++;
          if(arr[j]>arr[j+1]){
           int temp=arr[j];
           arr[j]=arr[j+1];
           arr[j+1]=temp;
          }
      }
      count--;
    }
       System.out.println("\nouter loop: "+outer);
       System.out.println("inner loop: "+inner);
       System.out.print("After sorting: ");
      for (int i=0;i<arr.length;i++){
       System.out.print(arr[i]+" ");
   }
       System.out.println();
}

    public static void main(String[] args) {
        int arr [] = {5,1,3,4,6,2};
       Bubble_Sort sort = new Bubble_Sort();
        System.out.print
        ("\nBubble sorting ");
       sort.bubbleSort(arr);
        System.out.print("\n\nEarly stop method ");
        int arr2 [] = {5,1,13,4,96,21};
       sort.early_stop_sorting(arr2);
        System.out.print("\nSort words:");
      String words[] = {"Apple", "Pie" , "Banana" , "Cat"};
       sort.sort_words(words);
        System.out.println("");
         int arr3 [] = {51,12,13,4,96,2};
         sort.reducestepssorting(arr3);
       
    }
    
}
