/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package intersection;

public class Intersection {
  public void intersect(int[] nums1, int[] nums2) {
        int size = 0;
        
        for(int i=0; i<nums1.length; i++){ 
            for(int j=0; j<nums2.length; j++){
                if(nums1[i]==nums2[j]){
                 size++;
                 break;
                }
            }
        }
        int arr[] = new int [size];
        int k = 0; 
       for(int i: nums1){
        for(int j: nums2){
            if(i == j){          
                arr[k++] = i;
                break;
                
}
}
}
       for(int i=0; i<arr.length; i++){
            System.out.print(arr[i] + " ");
        }
    }
    public static void main(String[] args) {
        int nums1 [] = {1,2,2,1};
        int nums2 [] = {2,2};
        Intersection i = new Intersection();
        i.intersect(nums1, nums2);
        
        
    }
    
}
