
package singlylinkedlist;
public class SinglyLinkedList {
    int size=0;
public class Node{
int data;
Node next;

Node(int data){
this.data = data;
this.next = null;
size++;
}
}

private Node head;
SinglyLinkedList(){
this.head = null;
}
public void Insert_At_Start(int data){
    Node newNode = new Node(data);
    newNode.next=head;
    head = newNode;

}
public void Insert_At_Last(int data){
Node newNode = new Node(data);
if(head==null){
head = newNode;
return;
}
Node cur = head;
while(cur.next != null){
cur = cur.next;
}
cur.next= newNode;
}
public void insert_at_middle(int data,int position){
   Node newNode = new Node(data);
   if(position == 0){
       newNode.next = head;
       head = newNode;
   }else{ Node current = head;
    
  for(int  i=0; i<position-1; i++){
      current = current.next;
}
  newNode.next = current.next;
  current.next = newNode;
  }   
}

void Delete_at_Start(){
if(head==null){
return;
}
head = head.next;
size--;

}
void Delete_at_Last(){

Node second_last = head;
Node last = head.next;
while(last.next!=null){
    last=last.next;
second_last = second_last.next;

}
second_last.next=null;
size--;
}
 public void deleteByValue(int data) {
       
        if (head.data == data) {
            head = head.next;
            System.out.println(data + " found and deleted.");
           
        }}
void Display_All(){
    Node current = head;
while(current!=null){
    System.out.print(current.data + "->");
    current = current.next;
}
}

public int countNodes() {
        int count = 0;
        Node temp = head;
        while (temp != null) {
            count++;
            temp = temp.next;
        }
        return count;
    }
void search(int data){
Node curNode = head;
boolean flag = false;
while(curNode!=null){
    curNode=curNode.next;
if(curNode.data==data){
   flag = true;
   break;
}
}
if(flag == true){
    System.out.println("Found");
}else{
    System.out.println("Not FOund");
}

}
public void reverse() {
        Node back = null;
        Node current = head;
        Node forw = null;
        
        while (current != null) {
            forw = current.next;   
            current.next = back;   
            back= current;       
            current = forw;
        }
        head = back;  
    }
    public static void main(String[] args) {
       
      SinglyLinkedList list = new SinglyLinkedList();
      
      list.Insert_At_Start(10);
      list.Insert_At_Start(20);
      list.Insert_At_Start(30);
      list.Display_All();
      list.Insert_At_Last(22);
      list.Insert_At_Last(90);
      list.Display_All();
      list.Delete_at_Start();
      System.out.println();
      list.Delete_at_Last();
      list.Display_All();
      System.out.println();
      System.out.println(list.size);
      list.search(22);
      list.insert_at_middle(20, 1);
      list.Display_All();
      list.Insert_At_Last(2);
      list.Display_All();   
      System.out.println();
      System.out.println(list.countNodes());   
      list.deleteByValue(20);
      list.Display_All();
      list.search(2);
      list.Display_All();
        System.out.println();
      list.reverse();
      list.Display_All();
    
      
      
    }
    
}
