
package binaryst;

public class BSTNode {
    int data;
    BSTNode left;
    BSTNode right;
    BSTNode(int data){
     this.data=data;
     left=null;
     right=null;
     }
}