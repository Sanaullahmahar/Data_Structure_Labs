package binaryst;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryST {
    BSTNode root;
  

    BinaryST() {
        root = null;
        
    }
    public BSTNode insert(BSTNode root, int key) {
        if (this.root == null) {
            this.root = new BSTNode(key);
            return root;
        }
        if (root == null) {
            return new BSTNode(key);
        }
        if (root.data == key) {
            return root;
        }
        if (key < root.data) {
            root.left = insert(root.left, key);
        }
        if (key > root.data) {
            root.right = insert(root.right, key);
        }
        return root;
    }
    public boolean searchNode(BSTNode root, int key) {
        if (root == null) {
            return false;
          }
        if (root.data == key) {
            return true;
          }
        if (key < root.data) {
            return searchNode(root.left, key);
           }
        return searchNode(root.right, key);
    }
    public void inorderTraversal(BSTNode root) {
        if (root != null) {
            inorderTraversal(root.left);
            System.out.print(root.data + " ");
            inorderTraversal(root.right);
        }
          }
    public void preorderTraversal(BSTNode root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorderTraversal(root.left);
            preorderTraversal(root.right);
        }
    }

   
    public void postorderTraversal(BSTNode root) {
        if (root != null) {
            postorderTraversal(root.left);
            postorderTraversal(root.right);
            System.out.print(root.data + " ");
        }
    }
    public void levelOrderTraversal() {
       if (root== null){
           return;
       }
        Queue<BSTNode> queue = new LinkedList<>();
        queue.add(root);
        while(!queue.isEmpty()){
            BSTNode cur = queue.remove();
            System.out.print(cur.data + " ");
            if (cur.left != null) queue.add(cur.left);
            if (cur.right != null) queue.add(cur.right);
        }
    }
   
    public int countNodes(BSTNode root) {
        if (root == null) {
            return 0;
        }
        return 1 + countNodes(root.left) + countNodes(root.right);
    }

    public static void main(String[] args) {
        BinaryST tree = new BinaryST();
        tree.insert(tree.root, 40);
        tree.insert(tree.root, 35);
        tree.insert(tree.root, 5);
        tree.insert(tree.root, 15);
        tree.insert(tree.root, 12);
        tree.insert(tree.root, 22);
        System.out.println("Inorder: ");
        tree.inorderTraversal(tree.root);
        System.out.println();
        boolean flag=tree.searchNode(tree.root, 1);
        if(flag==true){
            System.out.println("Found");
        }else{
            System.out.println("Not found");
        }
        System.out.println("Preorder:");
        tree.preorderTraversal(tree.root);
        System.out.println("\nPostorder:");
        tree.postorderTraversal(tree.root);
        System.out.println("\nLevel Order:");
        tree.levelOrderTraversal();
        System.out.println("\nTotal nodes in tree: " + tree.countNodes(tree.root));
    }
}