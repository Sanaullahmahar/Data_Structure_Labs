package graph2;
import java.util.ArrayList;
import java.util.List;

public class Graph2 {
    public void detectConnectedNodes(int[][] matrix) {
        int n=matrix.length;
        boolean[] visited = new boolean[n];
        List<List<Integer>> connectedNodes= new ArrayList<>();
        for (int i=0; i< n; i++) {
            if(!visited[i]){
                List<Integer> component = new ArrayList<>();
                dfs(matrix, i, visited, component);
                connectedNodes.add(component);
            }
        }
        

        System.out.println("Connected Nodes:");
        for (int i=0; i<connectedNodes.size(); i++) {
            System.out.print("Nodes " + (i+1) + ": ");
            System.out.println(connectedNodes.get(i));
            
        }
    }

    private void dfs(int[][] matrix, int node, boolean[] visited, List<Integer> Nodes) {
        visited[node] = true;
        Nodes.add(node+1); 
        for (int i=0; i<matrix.length; i++) {
            if (matrix[node][i]==1 && !visited[i]){
                dfs(matrix, i, visited, Nodes);
            }
        }
    }
    public static void main(String[] args) {
      Graph2 graph=new Graph2();
      int[][] matrix = {
            {0, 1, 1, 0, 0},
            {1, 0, 1, 0, 0},  
            {1, 1, 0, 0, 0},  
            {0, 0, 0, 0, 1},  
            {0, 0, 0, 1, 0}  
        };

        graph.detectConnectedNodes(matrix);
    }
    
}
